import { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { NavData } from "@/lib/types";
import {
  Album,
  ArrowBigUpDash,
  BookCheck,
  BookPlus,
  Building,
  CalendarArrowUp,
  ChevronDown,
  ChevronUp,
  CirclePlus,
  FilePenLine,
  FileUp,
  Globe,
  Grip,
  House,
  ListCollapse,
  Mails,
  PackageOpen,
  PanelRight,
  Sailboat,
  ScanLine,
  ScrollText,
  TramFront,
  Truck,
  User,
  UserRoundPlus,
} from "lucide-react";
import { useSelector } from "react-redux";
import { useAppSelector } from "@/app/hooks";

const Sidebar = () => {
  const navigate = useNavigate();
  const path = useLocation();
  const [isOpen, setIsOpen] = useState<any>({});
  const [navItems, setNavItems] = useState<NavData[]>([]);

  const handleNavigate = (value: NavData) => {
    if (value.link) {
      navigate(value.link);
    } else {
      setIsOpen({
        ...isOpen,
        [value.name]: !isOpen[value.name],
      });
    }
  };

  return (
    <div className="hidden bg-background lg:block col-span-2 sticky overflow-auto py-2 pr-2 space-y-2.5">
      {navItems.map((value, i) => {
        return (
          <div key={i}>
            {/* First level */}
            <div
              onClick={() => {
                handleNavigate(value);
              }}
              className={`flex cursor-pointer items-center justify-between py-2 rounded-r ${
                isOpen[value.name] && ""
              } ${
                value.link !== path.pathname
                  ? "ps-1 text-foreground border-s-4 border-s-background"
                  : "ps-1 text-background bg-red-500 font-semibold border-s-4 border-s-green-500"
              }`}
            >
              <div className="flex items-center gap-1">
                {value.icon}
                <p className="text-sm">{value.label}</p>
              </div>
              {value.children &&
                (isOpen[value.name] ? (
                  <ChevronUp className="w-4" />
                ) : (
                  <ChevronDown className="w-4" />
                ))}
            </div>

            {isOpen[value.name] && (
              <div className={`space-y-3 px-2 ms-1 bg-secondary py-3`}>
                {isOpen[value.name] &&
                  value.children?.map((data, i) => {
                    return (
                      <>
                        {/* Second level */}
                        <div
                          key={i}
                          onClick={() => {
                            handleNavigate(data);
                          }}
                          className={`cursor-pointer ${
                            data.link === path.pathname &&
                            "text-red-600 font-semibold"
                          }`}
                        >
                          <div className="flex items-center gap-1 ps-5">
                            {data.icon}
                            <p className="text-sm">{data.label || ""}</p>
                          </div>
                          {data.children &&
                            (isOpen[data.name] ? (
                              <ChevronUp className="w-4" />
                            ) : (
                              <ChevronDown className="w-4" />
                            ))}
                        </div>

                        {/* Third level */}
                        {isOpen[data.name] && (
                          <div className="bg-gray-200 dark:bg-gray-600 space-y-4">
                            {isOpen[data.name] &&
                              data.children?.map((data2, i) => {
                                return (
                                  <>
                                    <div
                                      key={i}
                                      onClick={() => {
                                        handleNavigate(data2);
                                      }}
                                      className={`flex  transition-all hover:opacity-70 items-center justify-between p-2 rounded cursor-pointer ${
                                        data.link === path.pathname &&
                                        "text-blue-700 dark:text-blue-400 font-semibold"
                                      }`}
                                    >
                                      <div className="flex items-center gap-3 text-[0.83rem]  ">
                                        {data.icon}
                                        {data.label || ""}
                                      </div>
                                    </div>
                                  </>
                                );
                              })}
                          </div>
                        )}
                      </>
                    );
                  })}
              </div>
            )}
          </div>
        );
      })}

      <div
        onClick={() => {
          navigate("/sidebar");
        }}
        className={`flex cursor-pointer items-center justify-between py-1.5 rounded-r ${
          "/sidebar" !== path.pathname
            ? "ps-1 text-foreground border-s-4 border-s-background"
            : "ps-1 text-background bg-red-500 font-semibold border-s-4 border-s-green-500"
        }`}
      >
        <div className="flex items-center gap-1">
          <PanelRight className="w-6" />
          <p className="text-sm">Sidebar</p>
        </div>
      </div>
    </div>
  );
};

export const allNavItems: NavData[] = [
  {
    name: "home",
    label: "Home",
    link: "/",
    icon: <House className="w-6" />,
    id: "1",
  },
  {
    name: "company",
    label: "Company",
    link: "/company",
    icon: <Building className="w-6" />,
    id: "2",
  },
  {
    name: "booking",
    label: "Booking",
    icon: <BookPlus className="w-6" />,
    id: "4",
    children: [
      {
        name: "bookingRpaMail",
        label: "Booking RPA Mail",
        link: "/booking-rpa-mail",
        icon: <Album className="w-4" />,
        id: "5",
      },
      {
        name: "bookingRequest",
        label: "Booking Request",
        link: "/create-booking-form",
        icon: <BookCheck className="w-4" />,
        id: "6",
      },
      {
        name: "cmaBookingApi",
        label: "CMA Booking API",
        link: "/cma-booking-api",
        icon: <Mails className="w-4" />,
        id: "7",
      },
    ],
  },
  {
    name: "shipmentOverview",
    label: "Shipment Overview",
    icon: <Sailboat className="w-6" />,
    link: "/shipment-overview",
    id: "8",
  },
  {
    name: "transport",
    label: "Transport",
    icon: <TramFront className="w-6" />,
    id: "9",
    children: [
      {
        name: "TransportOverview ",
        label: "Transport Overview",
        link: "/transport/transport-overview",
        icon: <CirclePlus className="w-4" />,
        id: "10",
      },
      {
        name: "AssignedTransport",
        label: "Assigned Transport",
        link: "/transport/assigned-transport",
        icon: <FileUp className="w-4" />,
        id: "11",
      },
    ],
  },
  {
    name: "shipment",
    label: "Shipment",
    icon: <Sailboat className="w-6" />,
    id: "12",
    children: [
      {
        name: "shipper",
        label: "Shipper",
        link: "/shipper/add-shipper",
        icon: <CirclePlus className="w-4" />,
        id: "13",
      },
      {
        name: "quickExportOrder",
        label: "Quick Export Order",
        link: "/shipment-booking-form",
        icon: <ArrowBigUpDash className="w-4" />,
        id: "14",
      },
      {
        name: "detailsExportOrder",
        label: "Details Export Order",
        link: "/details-export-order",
        icon: <CalendarArrowUp className="w-4" />,
        id: "15",
      },
      {
        name: "manualMapperOrder",
        label: "Manual Mapped Order",
        link: "/manual-mapped-order",
        icon: <ScanLine className="w-4" />,
        id: "16",
      },
    ],
  },
  {
    name: "containerBookingDetails",
    label: "Container Booking Details",
    icon: <ListCollapse className="w-6" />,
    id: "17",
    children: [
      {
        name: "containerBooking",
        label: "container Booking",
        link: "/booking-details/container-booking",
        icon: <CirclePlus className="w-4" />,
        id: "18",
      },
    ],
  },
  {
    name: "ShippingDocumentation",
    label: "Shipping Documentation",
    icon: <Truck className="w-6" />,
    id: "20",
    children: [
      {
        name: "shippingInstructionRequest",
        label: "Shipping Instruction Request",
        link: "/shipping-documentation/shipping-instruction-request",
        icon: <FilePenLine className="w-4" />,
        id: "21",
      },
      {
        name: "shippingInstructionList",
        label: "Shipping Instruction List",
        link: "/shipping-documentation/shipping-instruction-list",
        icon: <ScrollText className="w-4" />,
        id: "22",
      },
    ],
  },
  {
    name: "othersMasters",
    label: "Others Masters",
    icon: <Grip className="w-6" />,
    id: "23",
    children: [
      {
        name: "exporterBuyerMapList",
        label: "Export Buyer Map List",
        link: "/export-buyer-map-list",
        icon: <CirclePlus className="w-4" />,
        id: "24",
      },
      {
        name: "exporterList",
        label: "Exporter List",
        link: "/exporter-list",
        icon: <FileUp className="w-4" />,
        id: "25",
      },
      {
        name: "buyerConsigneeNotifyList",
        label: "Buyer / Consignee / Notify List",
        link: "/buyer-consignee-notify-list",
        icon: <ArrowBigUpDash className="w-4" />,
        id: "26",
      },
      {
        name: "shippingLineList",
        label: "Shipping Line List",
        link: "/shipping-line-list",
        icon: <CalendarArrowUp className="w-4" />,
        id: "27",
      },
      {
        name: "transportList",
        label: "Transport List",
        link: "/transport-list",
        icon: <CalendarArrowUp className="w-4" />,
        id: "28",
      },
      {
        name: "vehicleList",
        label: "Vehicle List",
        link: "/vehicle-list",
        icon: <CirclePlus className="w-4" />,
        id: "29",
      },
      {
        name: "driverList",
        label: "Driver List",
        link: "/driver-list",
        icon: <FileUp className="w-4" />,
        id: "30",
      },
      {
        name: "customHouseLocation",
        label: "Custom House Location",
        link: "/custom-house-location",
        icon: <ArrowBigUpDash className="w-4" />,
        id: "31",
      },
      {
        name: "emptyContainerYard",
        label: "Empty Container Yard",
        link: "/empty-container-yard",
        icon: <CalendarArrowUp className="w-4" />,
        id: "32",
      },
      {
        name: "commodityList",
        label: "Commodity List",
        link: "/commodity-list",
        icon: <CirclePlus className="w-4" />,
        id: "33",
      },
      {
        name: "portList",
        label: "Port List",
        link: "/port-list",
        icon: <FileUp className="w-4" />,
        id: "34",
      },
      {
        name: "containerList",
        label: "Container List",
        link: "container-list",
        icon: <CalendarArrowUp className="w-4" />,
        id: "36",
      },
      {
        name: "unitList",
        label: "Unit List",
        link: "/unit-list",
        icon: <CirclePlus className="w-4" />,
        id: "37",
      },
      {
        name: "priceOwner",
        label: "Price Owner",
        link: "/price-owner",
        icon: <FileUp className="w-4" />,
        id: "38",
      },
      {
        name: "countryList",
        label: "Country List",
        link: "/country-list",
        icon: <Globe className="w-4" />,
        id: "39",
      },
      {
        name: "placeList",
        label: "Place List",
        link: "/place-list",
        icon: <Globe className="w-4" />,
        id: "40",
      },
    ],
  },
  {
    name: "containerTrack",
    label: "Container Track",
    link: "/container-tracking",
    icon: <PackageOpen className="w-6" />,
    id: "41",
  },
  {
    name: "userDetails",
    label: "User Details",
    icon: <BookPlus className="w-6" />,
    id: "42",
    children: [
      {
        name: "systemUser",
        label: "System User",
        link: "/system-user",
        icon: <User className="w-4" />,
        id: "43",
      },
      {
        name: "Create User",
        label: "Create User",
        link: "/user",
        icon: <UserRoundPlus className="w-4" />,
        id: "44",
      },
    ],
  },
  {
    name: "rpaDetails",
    label: "RPA Details",
    icon: <Grip className="w-6" />,
    id: "45",
    children: [
      {
        name: "rpaMail",
        label: "RPA Mail",
        link: "/mail-list",
        icon: <CirclePlus className="w-4" />,
        id: "46",
      },
      {
        name: "rpaMailReport",
        label: "RPA Mail Report",
        link: "/rpa-mail-report",
        icon: <FileUp className="w-4" />,
        id: "47",
      },
      {
        name: "whatsappShipperAndAceList",
        label: "Whatsapp Shipper & Ace List",
        link: "/whatsapp-shipper-ace-list",
        icon: <ArrowBigUpDash className="w-4 whitespace-nowrap" />,
        id: "48",
      },
      {
        name: "whatsappShipperAceReport",
        label: "Whatsapp Shipper & Ace Report",
        link: "/whatsapp-shipper-ace-report",
        icon: <CalendarArrowUp className="w-4" />,
        id: "49",
      },
      {
        name: "whatsappTransporter",
        label: "Whatsapp Transporter",
        link: "/whatsapp-transporter",
        icon: <CirclePlus className="w-4" />,
        id: "50",
      },
      {
        name: "whatsappTransporterReport",
        label: "Whatsapp Transporter Report",
        link: "/whatsapp-transporter-report",
        icon: <FileUp className="w-4" />,
        id: "51",
      },
      {
        name: "pdfExtraction",
        label: "PDF Extraction",
        link: "/pdf-extraction",
        icon: <ArrowBigUpDash className="w-4" />,
        id: "52",
      },
      {
        name: "pdfExtractionReport",
        label: "PDF Extraction Report",
        link: "/pdf-extraction-report",
        icon: <ArrowBigUpDash className="w-4" />,
        id: "53",
      },
      {
        name: "containerTrackingReport",
        label: "Container Tracking Report",
        link: "/container-tracking-report",
        icon: <ArrowBigUpDash className="w-4" />,
        id: "54",
      },
    ],
  },
  {
    name: "Sidebar",
    label: "sidebar",
    link: "/sidebar",
    icon: <PanelRight className="w-6" />,
    id: "0",
  },
];

export const masterAdminNavItems: NavData[] = [
  {
    name: "home",
    label: "Home",
    link: "/",
    icon: <House className="w-6" />,
    id: "1",
  },
  {
    name: "company",
    label: "Company",
    link: "/company",
    icon: <Building className="w-6" />,
    id: "2",
  },
  {
    name: "userDetails",
    label: "User Details",
    icon: <BookPlus className="w-6" />,
    id: "42",
    children: [
      {
        name: "systemUser",
        label: "System User",
        link: "/system-user",
        icon: <User className="w-4" />,
        id: "43",
      },
      {
        name: "Create User",
        label: "Company User",
        link: "/user",
        icon: <UserRoundPlus className="w-4" />,
        id: "44",
      },
    ],
  },
  {
    name: "Sidebar",
    label: "sidebar",
    link: "/sidebar",
    icon: <PanelRight className="w-6" />,
    id: "0",
  },
];

export const rpaNavItems: NavData[] = [
  {
    name: "home",
    label: "Home",
    link: "/",
    icon: <House className="w-6" />,
    id: "1",
  },
  {
    name: "rpaDetails",
    label: "RPA Details",
    icon: <Grip className="w-6" />,
    id: "45",
    children: [
      {
        name: "rpaMail",
        label: "RPA Mail",
        link: "/mail-list",
        icon: <CirclePlus className="w-4" />,
        id: "46",
      },
      {
        name: "rpaMailReport",
        label: "RPA Mail Report",
        link: "/rpa-mail-report",
        icon: <FileUp className="w-4" />,
        id: "47",
      },
      {
        name: "whatsappShipperAndAceList",
        label: "Whatsapp Shipper & Ace List",
        link: "/whatsapp-shipper-ace-list",
        icon: <ArrowBigUpDash className="w-4 whitespace-nowrap" />,
        id: "48",
      },
      {
        name: "whatsappShipperAceReport",
        label: "Whatsapp Shipper & Ace Report",
        link: "/whatsapp-shipper-ace-report",
        icon: <CalendarArrowUp className="w-4" />,
        id: "49",
      },
      {
        name: "whatsappTransporter",
        label: "Whatsapp Transporter",
        link: "/whatsapp-transporter",
        icon: <CirclePlus className="w-4" />,
        id: "50",
      },
      {
        name: "whatsappTransporterReport",
        label: "Whatsapp Transporter Report",
        link: "/whatsapp-transporter-report",
        icon: <FileUp className="w-4" />,
        id: "51",
      },
      {
        name: "pdfExtraction",
        label: "PDF Extraction",
        link: "/pdf-extraction",
        icon: <ArrowBigUpDash className="w-4" />,
        id: "52",
      },
      {
        name: "pdfExtractionReport",
        label: "PDF Extraction Report",
        link: "/pdf-extraction-report",
        icon: <ArrowBigUpDash className="w-4" />,
        id: "53",
      },
      {
        name: "containerTrackingReport",
        label: "Container Tracking Report",
        link: "/container-tracking-report",
        icon: <ArrowBigUpDash className="w-4" />,
        id: "54",
      },
    ],
  },
];

export default Sidebar;
