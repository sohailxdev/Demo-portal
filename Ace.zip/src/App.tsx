import axios from "axios";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import Layout from "./components/layout/Layout";

axios.interceptors.request.use(
  function (config) {
    if (localStorage.getItem("token")) {
      config.headers.accesstoken = `${localStorage.getItem("token")}`;
    }
    return config;
  },
  function (error) {
    return Promise.reject(error);
  }
);

axios.interceptors.response.use(
  function (response) {
    return response;
  },
  function (error) {
    if (error.response.status === 401) {
      localStorage.removeItem("token");
      sessionStorage.clear();
      window.location.href = "/session-out";
    }
    return Promise.reject(error);
  }
);

const router = createBrowserRouter([
  {
    path: "/",
    element: (
      // <Protected>
      <Layout />
      // </Protected>
    ),
    children: [],
  },
]);

function App() {
  return <RouterProvider router={router}></RouterProvider>;
}

export default App;
